package com.example.assignment3scicalci

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val num1:EditText=findViewById(R.id.etnum1)
        val num2:EditText=findViewById(R.id.etnum2)
        val res:EditText=findViewById(R.id.etres)
        val bt1:Button=findViewById(R.id.btadd)
        val bt2:Button=findViewById(R.id.btmin)
        val bt3:Button=findViewById(R.id.btmul)
        val bt4:Button=findViewById(R.id.btdiv)
        val bt5:Button=findViewById(R.id.btmod)
        val bt6:Button=findViewById(R.id.btsin)
        val bt7:Button=findViewById(R.id.btcos)
        val bt8:Button=findViewById(R.id.bttan)
        val bt9:Button=findViewById(R.id.btsqr)
        val bt10:Button=findViewById(R.id.btpow)
        val bt11:Button=findViewById(R.id.btlog)
        bt1.setOnClickListener {
            val vl1 = num1.text.toString().toInt()
            val vl2 = num2.text.toString().toInt()

            val result = vl1+vl2
            res.setText(result.toString())
        }
        bt2.setOnClickListener {
            val vl1 = num1.text.toString().toInt()
            val vl2 = num2.text.toString().toInt()

            val result = vl1-vl2
            res.setText(result.toString())
        }
        bt3.setOnClickListener {
            val vl1 = num1.text.toString().toInt()
            val vl2 = num2.text.toString().toInt()

            val result = vl1*vl2
            res.setText(result.toString())
        }
        bt4.setOnClickListener {
            val vl1 = num1.text.toString().toInt()
            val vl2 = num2.text.toString().toInt()

            val result = vl1/vl2
            res.setText(result.toString())
        }
        bt5.setOnClickListener {
            val vl1 = num1.text.toString().toInt()
            val vl2 = num2.text.toString().toInt()

            val result = vl1%vl2
            res.setText(result.toString())
        }




    }
}